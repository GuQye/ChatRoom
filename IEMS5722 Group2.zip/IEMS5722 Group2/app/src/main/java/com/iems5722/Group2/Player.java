package com.iems5722.Group2;

/**
 * Created by wataxiwahuohuo on 2017/2/13.
 */

public class Player {
    private String name;
    public Player(String name){

        this.name = name;

    }

    public String getName(){
        return name;
    }
}
